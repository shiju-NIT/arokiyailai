<div class="fixed-sidebar-left">
				<ul class="nav navbar-nav side-nav nicescroll-bar">
					<li class="navigation-header">
						<span>Main</span> 
						<i class="zmdi zmdi-more"></i>
					</li>
					<!-- <li>
						<a href="dashboard.php" data-toggle="collapse" data-target="#dashboard_dr"><div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span class="right-nav-text">Dashboard</span></div><div class="pull-right"></div><div class="clearfix"></div></a>
						
					</li> -->
					<li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#ecom_dr"><div class="pull-left"><i class="zmdi zmdi-shopping-basket mr-20"></i><span class="right-nav-text">Disease</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="ecom_dr" class="collapse collapse-level-1">
							<li>
								<a href="add_disease.php">Add Diseases</a>
							</li>
							<li>
								<a href="view_disease.php">View Disease</a>
							</li>
							
						</ul>
					</li>

					<li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#chart_dr"><div class="pull-left"><i class="zmdi zmdi-chart-donut mr-20"></i><span class="right-nav-text">FPO</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="chart_dr" class="collapse collapse-level-1 two-col-list">
							<li>
								<a href="add_fpo.php">Add FPO</a>
							</li>
							<li>
								<a href="view_fpo.php">View FPO</a>
							</li>
							
							
						</ul>
					</li>

					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#icon_dr"><div class="pull-left"><i class="zmdi zmdi-iridescent mr-20"></i><span class="right-nav-text">Season Cut Flower</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="icon_dr" class="collapse collapse-level-1">
							<li>
								<a href="season_flower.php">Add Season Cut flower</a>
							</li>
							<li>
								<a href="view_season_flower.php">View Season Cut Flower</a>
							</li>
							<li>
								<a href="season_placeorder.php">Season Order</a>
							</li>
							<li>
								<a href="view_season_bill.php">View Season Order</a>
							</li>
							<li>
								<a href="view_sbill.php">View Season flower bill</a>
							</li>
							
						</ul>
					</li> -->

					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#app_dr"><div class="pull-left"><i class="zmdi zmdi-apps mr-20"></i><span class="right-nav-text">Flowers </span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="app_dr" class="collapse collapse-level-1">
							<li>
								<a href="add_flowers.php">Add Flowers</a>
							</li>
							<li>
								<a href="view_flowers.php">View Flowers</a>
							</li>
							<li>
								<a href="customercalc.php">Generate Bill</a>
							</li>
							<li>
								<a href="view_fbill.php">View Bill</a>
							</li>

						</ul>
					</li> -->
					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#ui_dr"><div class="pull-left"><i class="zmdi zmdi-smartphone-setup mr-20"></i><span class="right-nav-text">Backdrops</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="ui_dr" class="collapse collapse-level-1 two-col-list">
							<li>
								<a href="add_backdrops.php">Add Backdrops</a>
							</li>
							<li>
								<a href="view_backdrops.php">View Backdrops</a>
							</li>
							<li>
								<a href="backdropbill.php">Add Backdrop Bill</a>
							</li>
							<li>
								<a href="view_backdropbill.php">View Backdrop Bill</a>
							</li>
							
						</ul>
					</li> -->
					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#form_dr"><div class="pull-left"><i class="zmdi zmdi-edit mr-20"></i><span class="right-nav-text">Bouquet</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="form_dr" class="collapse collapse-level-1 two-col-list">
							<li>
								<a href="add_bouquet.php">Add Bouquet</a>
							</li>
							<li>
								<a href="view_bouquet.php">View Bouquet</a>
							</li>
							<li>
								<a href="bouquet_bill.php">Generate Bouquet Bill</a>
							</li>
							<li>
								<a href="view_bouquetbill.php">View Bouquet Bill</a>
							</li>
							
						</ul>
					</li> -->
					<!-- <li>
						<a href="gallery.php"><div class="pull-left"><i class="zmdi zmdi-flag mr-20"></i><span class="right-nav-text">Gallery</span></div><div class="clearfix"></div></a>
					</li> -->
					
					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#table_dr"><div class="pull-left"><i class="zmdi zmdi-format-size mr-20"></i><span class="right-nav-text">Accounts</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="table_dr" class="collapse collapse-level-1 two-col-list">
							<li>
								<a href="add_expense.php">Add expenses</a>
							</li>
							<li>
								<a href="view_expense.php">View Profit and Loss</a>
							</li>
							
							
						</ul>
					</li> -->
					<!-- <li>
						<a href="schedule/"><div class="pull-left"><i class="zmdi zmdi-book mr-20"></i><span class="right-nav-text">Events</span></div><div class="clearfix"></div></a>
					</li> -->
					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#pages_dr"><div class="pull-left"><i class="zmdi zmdi-google-pages mr-20"></i><span class="right-nav-text">Vendor</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="pages_dr" class="collapse collapse-level-1 two-col-list">
							<li>
								<a href="add_vendor.php">Add vendor</a>
							</li>
							<li>
								<a href="view_vendors.php">View vendor</a>
							</li>
							<li>
								<a href="vendor_purchase_list.php">Vendor Purchase List</a>
							</li>
						
						</ul>
					</li> -->
					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#maps_dr"><div class="pull-left"><i class="zmdi zmdi-map mr-20"></i><span class="right-nav-text">Purchase</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="maps_dr" class="collapse collapse-level-1">
							<li>
								<a href="purchase.php">Purchase From Vendor</a>
							</li>
							<li>
								<a href="purchase_list.php">Purchase List</a>
							</li>
						</ul>
					</li> -->
					<!-- <li><hr class="light-grey-hr mb-10"/></li>
					<li class="navigation-header">
						<span>featured</span> 
						<i class="zmdi zmdi-more"></i>
					</li> -->
					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#pages_dr"><div class="pull-left"><i class="zmdi zmdi-google-pages mr-20"></i><span class="right-nav-text">Special Pages</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="pages_dr" class="collapse collapse-level-1 two-col-list">
							<li>
								<a href="blank.html">Blank Page</a>
							</li>
							<li>
								<a href="javascript:void(0);" data-toggle="collapse" data-target="#auth_dr">Authantication pages<div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
								<ul id="auth_dr" class="collapse collapse-level-2">
									<li>
										<a href="login.html">Login</a>
									</li>
									<li>
										<a href="signup.html">Register</a>
									</li>
									<li>
										<a href="forgot-password.html">Recover Password</a>
									</li>
									<li>
										<a href="reset-password.html">reset Password</a>
									</li>
									<li>
										<a href="locked.html">Lock Screen</a>
									</li>
								</ul>
							</li>
							<li>
								<a href="javascript:void(0);" data-toggle="collapse" data-target="#invoice_dr">Invoice<div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
								<ul id="invoice_dr" class="collapse collapse-level-2">
									<li>
										<a href="invoice.html">Invoice</a>
									</li>
									<li>
										<a href="invoice-archive.html">Invoice Archive</a>
									</li>
								</ul>
							</li>
							<li>
								<a href="javascript:void(0);" data-toggle="collapse" data-target="#error_dr">error pages<div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
								<ul id="error_dr" class="collapse collapse-level-2">
									<li>
										<a href="404.html">Error 404</a>
									</li>
									<li>
										<a href="500.html">Error 500</a>
									</li>
								</ul>
							</li>
							<li>
								<a href="gallery.html">Gallery</a>
							</li>
							<li>
								<a href="timeline.html">Timeline</a>
							</li>
							<li>
								<a href="faq.html">FAQ</a>
							</li>
						</ul>
					</li> -->
					<!-- <li>
						<a href="documentation.html"><div class="pull-left"><i class="zmdi zmdi-book mr-20"></i><span class="right-nav-text">documentation</span></div><div class="clearfix"></div></a>
					</li> -->
					<!-- <li>
						<a href="javascript:void(0);" data-toggle="collapse" data-target="#dropdown_dr_lv1"><div class="pull-left"><i class="zmdi zmdi-filter-list mr-20"></i><span class="right-nav-text">multilevel</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
						<ul id="dropdown_dr_lv1" class="collapse collapse-level-1">
							<li>
								<a href="#">Item level 1</a>
							</li>
							<li>
								<a href="javascript:void(0);" data-toggle="collapse" data-target="#dropdown_dr_lv2">Dropdown level 2<div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
								<ul id="dropdown_dr_lv2" class="collapse collapse-level-2">
									<li>
										<a href="#">Item level 2</a>
									</li>
									<li>
										<a href="#">Item level 2</a>
									</li>
								</ul>
							</li>
						</ul>
					</li> -->
				</ul>
			</div>